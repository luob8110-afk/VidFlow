import json
from pathlib import Path
import baseline as b

ROOT=Path(__file__).resolve().parent
INDEX='idx_videos_time_id_author'

def set_variant(variant):
    with b.db() as conn,conn.cursor() as cur:
        cur.execute("SELECT COUNT(*) FROM information_schema.statistics WHERE table_schema=DATABASE() AND table_name='videos' AND index_name=%s",(INDEX,))
        exists=cur.fetchone()[0]>0
        if variant=='B' and not exists:
            cur.execute(f'CREATE INDEX {INDEX} ON videos (create_time DESC,id DESC,author_id)')
        if variant=='A' and exists:
            cur.execute(f'DROP INDEX {INDEX} ON videos')
        cur.execute('ANALYZE TABLE videos')

def main():
    plans=[]; expected={}
    with b.db() as conn,conn.cursor() as cur:
        cur.execute('DELETE FROM videos WHERE id>100000 AND author_id<=1000')
    for variant in ['A','B']:
        set_variant(variant)
        with b.db() as conn,conn.cursor() as cur:
            for group,count in enumerate(b.COUNTS):
                for reader_index in [0,49,99]:
                    account=b.reader_id(group,reader_index);cursor=None
                    for page in range(1,4):
                        sql='SELECT * FROM videos WHERE author_id IN (SELECT vlogger_id FROM socials WHERE follower_id=%s)'
                        params=[account]
                        if cursor:
                            sql+=' AND (create_time < %s OR (create_time = %s AND id < %s))'
                            params.extend([cursor[0],cursor[0],cursor[1]])
                        sql+=' ORDER BY create_time DESC,id DESC LIMIT 11'
                        cur.execute(sql,params);rows=cur.fetchall();ids=[row[0] for row in rows[:10]]
                        key=f'{count}-{reader_index}-{page}'
                        if variant=='A':expected[key]=ids
                        else:assert ids==expected[key],key
                        for repeat in range(3):
                            cur.execute('EXPLAIN ANALYZE '+sql,params)
                            plans.append({'variant':variant,'follows':count,'reader_index':reader_index,'page':page,'repeat':repeat+1,'plan':cur.fetchone()[0]})
                        last=rows[9];cursor=(last[7],last[0])
            cur.execute("SELECT index_name,stat_name,stat_value FROM mysql.innodb_index_stats WHERE database_name=DATABASE() AND table_name='videos' AND stat_name IN ('size','n_leaf_pages')")
            (ROOT/f'index-size-{variant}.json').write_text(json.dumps(cur.fetchall()))
    (ROOT/'preliminary-plans.json').write_text(json.dumps(plans,indent=2),encoding='utf-8')
    for variant in ['A','B']:
        for count in b.COUNTS:
            item=next(x for x in plans if x['variant']==variant and x['follows']==count and x['reader_index']==0 and x['page']==1)
            print(json.dumps(item),flush=True)

if __name__=='__main__':main()
