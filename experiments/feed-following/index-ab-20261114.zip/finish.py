import difflib
import hashlib
import json
import statistics
import zipfile
from pathlib import Path

import baseline as b
from preliminary import set_variant

ROOT=Path(__file__).resolve().parent
REPO=Path('D:/Golang/feedsystem_video_go')

def main():
    all_runs={}
    for variant in ['A','B']:
        all_runs[variant]=[json.loads(line) for line in (ROOT/variant/'runs.jsonl').read_text().splitlines() if line.strip()]
        assert len(all_runs[variant])==12
        assert all(29<=r['elapsed_s']<=35 and r['environment_match'] and r['cache_estimate_assumptions_hold'] for r in all_runs[variant])
        assert all(r['kinds']['main']['requests']==600 and all(k['errors']==0 for k in r['kinds'].values()) for r in all_runs[variant])
    diagnostics=[]
    with b.db() as conn,conn.cursor() as cur:
        cur.execute('DELETE FROM videos WHERE id>100000 AND author_id<=1000')
    for variant in ['A','B']:
        set_variant(variant)
        with b.db() as conn,conn.cursor() as cur:
            for count,account in [(0,1001),(1,30001),(20,10000),(100,11000),(200,12000)]:
                table='videos' if variant=='A' else 'videos FORCE INDEX (idx_videos_time_id_author)'
                sql=f'SELECT * FROM {table} WHERE author_id IN (SELECT vlogger_id FROM socials WHERE follower_id=%s) ORDER BY create_time DESC,id DESC LIMIT 11'
                cur.execute('EXPLAIN ANALYZE '+sql,(account,))
                diagnostics.append({'variant':variant,'follows':count,'plan':cur.fetchone()[0]})
            cur.execute("SELECT index_name,stat_name,stat_value FROM mysql.innodb_index_stats WHERE database_name=DATABASE() AND table_name='videos' AND stat_name IN ('size','n_leaf_pages')")
            (ROOT/f'final-index-size-{variant}.json').write_text(json.dumps(cur.fetchall()))
    set_variant('A')
    (ROOT/'diagnostic-plans.json').write_text(json.dumps(diagnostics,indent=2),encoding='utf-8')
    baseline_env=json.loads(Path('D:/Golang/tmp/vidflow-correct-baseline-20261114/environment.json').read_text())
    assert b.environment()==baseline_env,'baseline environment was not restored'
    (ROOT/'restoration.json').write_text(json.dumps({'baseline_restored':True,'main_works':100000}))
    rows=[]
    for count in b.COUNTS:
        for mode in ['refresh','paging']:
            item={'follows':count,'mode':mode}
            for variant in ['A','B']:
                selected=[r for r in all_runs[variant] if r['follow_count']==count and r['mode']==mode]
                assert len(selected)==2
                med=lambda path:statistics.median(reduce_path(r,path) for r in selected)
                item[variant]={'p50':med(['kinds','main','http_p50_ms']),'p95':med(['kinds','main','http_p95_ms']),
                    'p95_values':[r['kinds']['main']['http_p95_ms'] for r in selected],
                    'reads':med(['mysql_rows_read_per_feed_request']),
                    'publish_p50':med(['kinds','publish','http_p50_ms']),
                    'publish_p95':med(['kinds','publish','http_p95_ms']),
                    'probe_p95':med(['kinds','freshness','http_p95_ms'])}
            item['p95_reduction_pct']=(1-item['B']['p95']/item['A']['p95'])*100
            rows.append(item)
    (ROOT/'comparison.json').write_text(json.dumps(rows,indent=2))
    relative='backend/internal/feed/repo.go'
    patch=''.join(difflib.unified_diff((REPO/relative).read_text(encoding='utf-8').splitlines(True),
        (ROOT/'candidate-source'/relative).read_text(encoding='utf-8').splitlines(True),fromfile='a/'+relative,tofile='b/'+relative))
    (ROOT/'candidate.patch').write_text(patch,encoding='utf-8')
    (ROOT/'candidate.sql').write_text('CREATE INDEX idx_videos_time_id_author ON videos (create_time DESC, id DESC, author_id);\n',encoding='utf-8')
    index_stats=json.loads((ROOT/'final-index-size-B.json').read_text())
    pages=next(v for n,s,v in index_stats if n=='idx_videos_time_id_author' and s=='size')
    report='''# 2.2 查询索引短测对照

2026-11-14 完成。固定 1,000 名作者、100,000 条主作品，每组 1,000 名读者，其中相同的 100 名活跃读者承担负载。关注数为 20、100、200，每秒 20 次主请求和一次发布，发布后立即刷新检查。

## 方案与筛选

A 使用当前正确版本与原有索引。最初仅新增时间、ID、作者联合索引，SQL 抽样仍然选择作者索引并排序。因此正式 B 使用新索引加 FORCE INDEX 指定访问路线，业务改动位于关注查询的 Table 表达式中。

抽样中，关注 200 人的首页从读取约 20,000 条候选并排序，变为沿时间索引扫描 104 条后得到一页及下一条。关注 100 人的对应抽样从约 10,000 条变为 140 条。初筛同时核对三位读者各三页的 ID 序列。

## 短测协议

每种关注数和场景执行 A1、B1、B2、A2。场景为主动刷新和连续三页，每轮 30 秒、600 次主请求。共 24 轮，正式负载计划 12 分钟，主请求 14,400 次、发布 720 次、发布后刷新检查 720 次，正式测量请求共 15,840 次。

每轮清理上一轮发布作品、重置独立 Redis 并通过 API 预热。资源、容器环境变量、MySQL 参数、请求轨迹、数据规模保持一致，实验变量为查询访问路线对应的镜像、关注查询源码和新增索引。每轮前后核验各自环境，跨方案核验其他字段一致。

P95 表值为两轮 P95 的中位数。均摊读取量为整个测量窗口的 InnoDB 读取行数除以主请求与刷新探针请求数，包含固定的单作者探针和后台事件处理。发布 P95 每轮只有 30 个样本，需要结合原始记录解释。

| 关注数 | 场景 | A P95 ms | B P95 ms | 主请求 P95 降幅 | A 均摊读取行数 | B 均摊读取行数 |
|---:|---|---:|---:|---:|---:|---:|
'''
    for r in rows:
        label='主动刷新' if r['mode']=='refresh' else '连续三页'
        report+=f"| {r['follows']} | {label} | {r['A']['p95']:.2f} | {r['B']['p95']:.2f} | {r['p95_reduction_pct']:.1f}% | {r['A']['reads']:,.1f} | {r['B']['reads']:,.1f} |\n"
    report+='\n## 发布与空间\n\n| 关注数 | 场景 | A 发布 P50 / P95 ms | B 发布 P50 / P95 ms |\n|---:|---|---:|---:|\n'
    for r in rows:
        label='主动刷新' if r['mode']=='refresh' else '连续三页'
        report+=f"| {r['follows']} | {label} | {r['A']['publish_p50']:.2f} / {r['A']['publish_p95']:.2f} | {r['B']['publish_p50']:.2f} / {r['B']['publish_p95']:.2f} |\n"
    report+=f'\n新增索引分配 {pages} 个 16 KiB 页，约 {pages*16/1024:.2f} MiB。两方案每次发布均新增作品与 Outbox 各一行，投递后删除一行。新索引增加索引维护工作，表内行数计数与索引项维护需要分别解释。\n'
    report+='''
## 退化与采用判断

B 中仅关注一名作者的刷新探针明显变慢，诊断计划与每组探针分位数保存在归档。这部分额外扫描也进入均摊读取量，因此关注 20 人的整个混合负载读取量增加，尽管主请求耗时有所降低。

本轮确认 B 对 20～200 人的主请求有收益，同时确认统一强制该索引会使低关注场景退化。候选方案适合进一步验证查询路线选择规则，默认实现保留 A。由于候选存在已复现的退化，本轮以短测形成取舍结论，长测确认安排在路线选择规则验证通过之后。

## 正确性、运行异常与交付

24 个正式轮次全部通过页内去重、关注集合、排序、下一页游标、三页周期跨页去重、发布后刷新与固定 25 条同时间作品完整翻页检查。启动试跑中 API 先于消息队列就绪，Outbox 未排空，该尝试保留在 pilot 并重跑。切换方案时的旧 HTTP 连接也曾导致预热断开，测试端改为每轮重建连接后继续执行。

源码候选在独立镜像中验证，candidate.patch 与 candidate.sql 一起交付。测试结束后恢复独立环境至 A，清理测量新增作品，保留固定样本，并停止压测容器。2.1 长测与本轮短测各自保留，方案取舍使用本轮 A/B 结果。

原始证据包含环境摘要、计划、逐请求 CSV、资源采样、源码候选、差异与 SQL。本机工作目录为 D:/Golang/tmp/vidflow-index-ab-20261114。

[原始对照证据](index-ab-20261114.zip)
'''
    target=REPO/'experiments/feed-following'
    (target/'05-index-ab-short-results.md').write_text(report,encoding='utf-8')
    checksums={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in ROOT.rglob('*') if p.is_file() and '__pycache__' not in str(p) and p.name!='SHA256SUMS.json'}
    (ROOT/'SHA256SUMS.json').write_text(json.dumps(checksums,indent=2))
    archive=target/'index-ab-20261114.zip'
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
        for p in ROOT.rglob('*'):
            if p.is_file() and '__pycache__' not in str(p):z.write(p,str(p.relative_to(ROOT)))
    print(json.dumps({'rows':rows,'index_mib':pages*16/1024,'archive':str(archive)},indent=2))

def reduce_path(value,path):
    for key in path:value=value[key]
    return value

if __name__=='__main__':main()
