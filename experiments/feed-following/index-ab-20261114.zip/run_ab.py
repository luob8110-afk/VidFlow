"""Short, paired API experiment using the unchanged 2.1 workload generator."""
import asyncio
import copy
import json
import random
import shutil
import subprocess
import time
from pathlib import Path

import aiohttp
import baseline as b
from preliminary import set_variant

ROOT=Path(__file__).resolve().parent
ORIGINAL=Path('D:/Golang/tmp/vidflow-correct-baseline-20261114')
BASE_ENV=json.loads((ORIGINAL/'environment.json').read_text(encoding='utf-8'))
CURRENT=None

def stable(env):
    value=copy.deepcopy(env)
    value.pop('video_schema')
    value['source_hashes'].pop('backend\\internal\\feed\\repo.go')
    for container in value['containers']:
        if container['name'].endswith('-backend-1'):container.pop('image')
    return value

def switch(variant):
    global CURRENT
    if variant==CURRENT:return
    set_variant(variant)
    image='vidflow-correct-baseline-api:20261114' if variant=='A' else 'vidflow-index-candidate-api:20261114'
    override=ROOT/'image-override.yaml'
    override.write_text('services:\n  backend:\n    image: '+image+'\n',encoding='utf-8')
    command=['docker','compose','-p',b.PROJECT,'-f',str(ORIGINAL/'compose.yaml'),'-f',str(override)]
    subprocess.run(['docker','exec',b.PROJECT+'-rabbitmq-1','rabbitmq-diagnostics','-q','check_port_connectivity'],check=True,stdout=subprocess.DEVNULL)
    subprocess.run(command+['up','-d','--no-deps','--force-recreate','backend'],check=True,stdout=subprocess.DEVNULL)
    subprocess.run(command+['restart','web'],check=True,stdout=subprocess.DEVNULL)
    CURRENT=variant
    time.sleep(1)

async def main():
    combinations=[(group,mode) for group in range(3) for mode in ['refresh','paging']]
    random.Random(b.SEED).shuffle(combinations)
    (ROOT/'short-order.json').write_text(json.dumps(combinations))
    b.DURATION=30
    for variant in ['A','B']:
        directory=ROOT/variant;directory.mkdir(exist_ok=True)
        for name in ['compose.yaml','config.yaml','nginx.conf']:shutil.copy2(ORIGINAL/name,directory/name)
    for group,mode in combinations:
        for variant,repeat in [('A',1),('B',1),('B',2),('A',2)]:
            result_file=ROOT/variant/'runs.jsonl'
            completed=[json.loads(line)['name'] for line in result_file.read_text().splitlines() if line.strip()] if result_file.exists() else []
            if f'f{b.COUNTS[group]}_{mode}_r{repeat}' in completed:
                continue
            print(json.dumps({'starting':variant,'follows':b.COUNTS[group],'mode':mode,'repeat':repeat}),flush=True)
            switch(variant)
            b.ROOT=ROOT/variant
            b.REPO=Path('D:/Golang/feedsystem_video_go') if variant=='A' else ROOT/'candidate-source'
            env=b.environment()
            assert stable(env)==stable(BASE_ENV),'uncontrolled environment difference'
            b.dump('environment.json',env)
            async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=5),connector=aiohttp.TCPConnector(limit=200)) as session:
                await b.run_case(session,group,mode,repeat,env)
        print(json.dumps({'pair_complete':True,'follows':b.COUNTS[group],'mode':mode}),flush=True)
    (ROOT/'short.done').touch()

if __name__=='__main__':asyncio.run(main())
