"""Isolated baseline for the unchanged VidFlow API, through its Nginx proxy."""
import asyncio
import base64
import csv
import hashlib
import hmac
import json
import math
import random
import statistics
import subprocess
import sys
import time
from collections import Counter, defaultdict
from datetime import datetime, timedelta, timezone
from pathlib import Path

import aiohttp
import pymysql
import redis

ROOT = Path(__file__).resolve().parent
BASE = "http://127.0.0.1:18080/api"
DATA_TIME = datetime(2026, 11, 1, 12)
DATA_EPOCH = int(DATA_TIME.replace(tzinfo=timezone.utc).timestamp())
SECRET = b"vidflow-baseline-test-only"
COUNTS = (20, 200, 1000)
READERS = 1000
AUTHORS = 1000
VIDEOS = 100000
DURATION = 8
REPEATS = 3
RATES = {"warm": (100, 300), "uncached": (5, 20)}


def database():
    return pymysql.connect(host="127.0.0.1", port=13307, user="root",
                           password="baseline-local", database="vidflow_baseline",
                           autocommit=True, charset="utf8mb4")


def cache():
    return redis.Redis(host="127.0.0.1", port=16379, password="baseline-local")


def token(account_id):
    def encode(value):
        return base64.urlsafe_b64encode(json.dumps(value, separators=(",", ":")).encode()).rstrip(b"=")
    now = int(time.time()) // 86400 * 86400
    head = encode({"alg": "HS256", "typ": "JWT"})
    body = encode({"account_id": account_id, "username": f"bench{account_id}",
                   "iat": now, "nbf": now, "exp": now + 86400})
    message = head + b"." + body
    signature = base64.urlsafe_b64encode(hmac.new(SECRET, message, hashlib.sha256).digest()).rstrip(b"=")
    return (message + b"." + signature).decode()


def ids(group):
    return range(10000 + group * READERS, 10000 + (group + 1) * READERS)


def follows(group, index):
    rng = random.Random(20261113 + group * READERS + index)
    return {1, *rng.sample(range(2, AUTHORS + 1), COUNTS[group] - 1)}


def seed():
    db = database()
    cur = db.cursor()
    cur.execute("SELECT COUNT(*) FROM accounts")
    if cur.fetchone()[0]:
        raise RuntimeError("The isolated database already has accounts. Refusing to overwrite it.")
    accounts = list(range(1, AUTHORS + 3)) + list(range(10000, 13000)) + [20000, 20001] + list(range(20010, 20040))
    cur.executemany("INSERT INTO accounts (id,username,password,token,refresh_token) VALUES (%s,%s,%s,%s,%s)",
                    [(i, f"bench{i}", "unused-fixture-account", token(i), "") for i in accounts])
    batch = []
    for i in range(1, VIDEOS + 1):
        author = (i - 1) % AUTHORS + 1
        batch.append((i, author, f"bench{author}", f"fixture{i}", "baseline", "/fixture.mp4",
                      "/fixture.jpg", DATA_TIME + timedelta(seconds=i), 0, 0))
        if len(batch) == 2000:
            cur.executemany("INSERT INTO videos (id,author_id,username,title,description,play_url,cover_url,create_time,likes_count,popularity) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)", batch)
            batch.clear()
    edges = []
    for group in range(3):
        for index, reader in enumerate(ids(group)):
            edges.extend((reader, author) for author in follows(group, index))
            if len(edges) >= 5000:
                cur.executemany("INSERT INTO socials (follower_id,vlogger_id) VALUES (%s,%s)", edges)
                edges.clear()
    edges.extend((i, 1002) for i in range(20010, 20040))
    edges.extend([(20000, 1), (20001, 1)])
    cur.executemany("INSERT INTO socials (follower_id,vlogger_id) VALUES (%s,%s)", edges)
    pipe = cache().pipeline()
    for i in accounts:
        pipe.set(f"v1:account:{i}", token(i), ex=7200)
    pipe.execute()
    cur.execute("ANALYZE TABLE accounts, videos, socials, likes")
    metadata = {"authors": AUTHORS + 2, "reader_groups": dict(zip(map(str, COUNTS), [READERS] * 3)),
                "videos": VIDEOS, "seed": 20261113, "data_start": DATA_TIME.isoformat(),
                "jwt_setup": "fixture tokens signed with test key, validated by original JWT middleware",
                "load_path": BASE, "page_size": 10, "duration_s": DURATION,
                "repeats": REPEATS, "rates": RATES, "timestamp": datetime.now().isoformat()}
    for table in ("accounts", "videos", "socials"):
        cur.execute(f"SELECT COUNT(*) FROM {table}")
        metadata[table] = cur.fetchone()[0]
    metadata["explain"] = {}
    for group, count in enumerate(COUNTS):
        cur.execute("EXPLAIN SELECT * FROM videos WHERE author_id IN (SELECT vlogger_id FROM socials WHERE follower_id=%s) ORDER BY create_time DESC LIMIT 10", (ids(group).start,))
        columns = [c[0] for c in cur.description]
        metadata["explain"][str(count)] = [dict(zip(columns, r)) for r in cur.fetchall()]
    (ROOT / "fixture.json").write_text(json.dumps(metadata, indent=2, default=str), encoding="utf8")
    print(json.dumps(metadata, default=str), flush=True)
    db.close()


def percentile(values, p):
    if not values:
        return None
    ordered = sorted(values)
    return round(ordered[max(0, math.ceil(len(ordered) * p) - 1)], 3)


def metrics_snapshot():
    result = {}
    with database() as db:
        with db.cursor() as cur:
            cur.execute("SHOW GLOBAL STATUS WHERE Variable_name IN ('Com_select','Com_insert','Com_update','Com_delete','Innodb_rows_read','Innodb_rows_inserted','Innodb_buffer_pool_reads','Innodb_buffer_pool_read_requests','Threads_connected','Threads_running')")
            result.update({k: int(v) for k, v in cur.fetchall()})
    result.update({"redis_" + k: cache().info("stats")[k] for k in ("keyspace_hits", "keyspace_misses", "total_commands_processed")})
    return result


async def post(session, path, account, body):
    async with session.post(BASE + path, json=body,
                            headers={"Authorization": "Bearer " + token(account)}) as response:
        return response.status, await response.json(content_type=None)


async def warm(session, group):
    sem = asyncio.Semaphore(10)
    async def one(reader):
        async with sem:
            status, body = await post(session, "/feed/listByFollowing", reader, {"limit": 10, "latest_time": 0})
            assert status == 200 and len(body["video_list"]) == 10, (status, body)
    await asyncio.gather(*(one(i) for i in ids(group)))
    for attempt in range(5):
        missing = [i for i in ids(group) if not cache().exists(f"v1:feed:listByFollowing:limit=10:accountID={i}:before=0")]
        if not missing:
            break
        for reader in missing:
            await one(reader)
    cached = sum(cache().exists(f"v1:feed:listByFollowing:limit=10:accountID={i}:before=0") for i in ids(group))
    print(json.dumps({"warmup_follow_count": COUNTS[group], "cached_pages": cached, "expected": READERS}), flush=True)
    if cached != READERS:
        raise RuntimeError("Warm-cache scenario could not be prepared through the API")


async def run_case(session, group, mode, rate, repeat, slot):
    before = metrics_snapshot()
    rows = []
    wall_started = time.time()
    start = time.perf_counter()
    count = rate * DURATION
    follow_sets = {r: follows(group, r - ids(group).start) for r in ids(group)}
    async def one(sequence, target):
        sent = time.perf_counter()
        reader = ids(group).start + sequence % READERS
        cursor = 0
        if mode == "uncached":
            cursor = DATA_EPOCH + 80000 - slot * 200 - sequence // READERS
        status, valid, error = 0, False, ""
        try:
            status, body = await post(session, "/feed/listByFollowing", reader, {"limit": 10, "latest_time": cursor})
            page = body.get("video_list", [])
            valid = (status == 200 and len(page) == 10 and len({v["id"] for v in page}) == 10
                     and all(v["author"]["id"] in follow_sets[reader] for v in page)
                     and all(a["create_time"] >= b["create_time"] for a, b in zip(page, page[1:])))
            if not valid:
                error = str(body)[:150]
        except Exception as exc:
            error = type(exc).__name__ + ": " + str(exc)
        end = time.perf_counter()
        rows.append((sequence, reader, cursor, status, valid, (sent-target)*1000,
                     (end-sent)*1000, (end-target)*1000, error))
    tasks = []
    for sequence in range(count):
        target = start + sequence / rate
        delay = target - time.perf_counter()
        if delay > 0:
            await asyncio.sleep(delay)
        tasks.append(asyncio.create_task(one(sequence, target)))
    await asyncio.gather(*tasks)
    elapsed = time.perf_counter() - start
    after = metrics_snapshot()
    name = f"f{COUNTS[group]}_{mode}_{rate}rps_r{repeat}"
    with (ROOT / (name + ".csv")).open("w", newline="", encoding="utf8") as stream:
        writer = csv.writer(stream)
        writer.writerow(("sequence", "account", "cursor", "status", "valid_page", "scheduler_lag_ms", "http_ms", "scheduled_to_complete_ms", "error"))
        writer.writerows(sorted(rows))
    success = [r for r in rows if r[4]]
    result = {"name": name, "follow_count": COUNTS[group], "cache": mode, "target_rps": rate,
              "started_at_unix": wall_started,
              "repeat": repeat, "requests": count, "elapsed_s": round(elapsed, 3),
              "valid_pages": len(success), "errors": count-len(success),
              "valid_rps_including_drain": round(len(success)/elapsed, 2),
              "http_p50_ms": percentile([r[6] for r in success], .5),
              "http_p95_ms": percentile([r[6] for r in success], .95),
              "http_p99_ms": percentile([r[6] for r in success], .99),
              "e2e_p95_ms": percentile([r[7] for r in rows], .95),
              "scheduler_lag_p95_ms": percentile([r[5] for r in rows], .95),
              "status": dict(Counter(r[3] for r in rows)),
              "counter_delta": {k: after[k]-before[k] for k in before}}
    with (ROOT / "runs.jsonl").open("a", encoding="utf8") as stream:
        stream.write(json.dumps(result) + "\n")
    print(json.dumps(result), flush=True)
    return result


async def load():
    timeout = aiohttp.ClientTimeout(total=5)
    connector = aiohttp.TCPConnector(limit=1000)
    async with aiohttp.ClientSession(timeout=timeout, connector=connector) as session:
        await settle_database()
        for group in range(3):
            await warm(session, group)
        cases = [(group, mode, rate, repeat) for group in range(3)
                 for mode in ("warm", "uncached") for rate in RATES[mode] for repeat in range(1, REPEATS+1)]
        random.Random(20261113).shuffle(cases)
        for slot, (group, mode, rate, repeat) in enumerate(cases):
            await settle_database()
            await run_case(session, group, mode, rate, repeat, slot)
            await asyncio.sleep(1)
    (ROOT / "load.done").touch()


async def settle_database():
    deadline = time.perf_counter() + 45
    quiet = 0
    while time.perf_counter() < deadline:
        with database() as db:
            with db.cursor() as cur:
                cur.execute("SHOW GLOBAL STATUS LIKE 'Threads_running'")
                running = int(cur.fetchone()[1])
        quiet = quiet + 1 if running <= 2 else 0
        if quiet >= 2:
            return
        await asyncio.sleep(.5)
    raise RuntimeError("MySQL has not drained; refusing to contaminate the next scenario")


async def correctness():
    result = {}
    async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=5)) as session:
        # Reader follows one author with 100 known videos. Consume exactly the public cursor.
        page_ids = []
        cursor = 0
        page_sizes = []
        for _ in range(20):
            status, body = await post(session, "/feed/listByFollowing", 20000, {"limit": 10, "latest_time": cursor})
            assert status == 200, body
            page_sizes.append(len(body["video_list"]))
            page_ids.extend(v["id"] for v in body["video_list"])
            if not body["has_more"]:
                break
            cursor = body["next_time"]
        result["pagination_unique_seconds"] = {"expected": 100, "received": len(page_ids),
                                                "unique": len(set(page_ids)), "page_sizes": page_sizes}
        with database() as db:
            with db.cursor() as cur:
                # Fixed 25-video timestamp tie, independent of the load-test data.
                cur.execute("INSERT INTO socials (follower_id,vlogger_id) VALUES (20001,1001)")
                tie_time = DATA_TIME + timedelta(days=2)
                cur.executemany("INSERT INTO videos (author_id,username,title,description,play_url,cover_url,create_time) VALUES (1001,'bench1001',%s,'','/tie.mp4','/tie.jpg',%s)",
                                [(f"tie{i}", tie_time) for i in range(25)])
        received = []
        cursor = 0
        for _ in range(3):
            _, body = await post(session, "/feed/listByFollowing", 20001, {"limit": 10, "latest_time": cursor})
            received.extend(v["id"] for v in body["video_list"] if v["author"]["id"] == 1001)
            cursor = body["next_time"]
        result["pagination_same_second"] = {"expected_tied_videos": 25, "received_tied_videos": len(set(received))}
    (ROOT / "correctness.json").write_text(json.dumps(result, indent=2), encoding="utf8")
    print(json.dumps(result), flush=True)


async def publish_checks():
    result = {"samples": []}
    async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=5)) as session:
        # Keep an ordinary reader warm before publish, another reader is only warmed afterwards.
        warm_reader = 12999
        await post(session, "/feed/listByFollowing", warm_reader, {"limit": 10, "latest_time": 0})
        for author, fans in ((1001, 1), (1002, 30), (1, 3002)):
            for sample in range(5):
                before = metrics_snapshot()
                start = time.perf_counter()
                status, body = await post(session, "/video/publish", author,
                                          {"title": f"publishbaseline{author}x{sample}", "description": "baseline",
                                           "play_url": "/fixture.mp4", "cover_url": "/fixture.jpg"})
                ack = time.perf_counter()
                assert status == 200 and body["id"], body
                video_id = body["id"]
                # Observe actual MQ consumer output directly, without rebuilding latest-feed cache.
                deadline = ack + 5
                while cache().zscore("v1:feed:global_timeline", video_id) is None and time.perf_counter() < deadline:
                    await asyncio.sleep(.02)
                timeline = time.perf_counter()
                result["samples"].append({"author": author, "followers": fans, "video_id": video_id,
                                          "http_ack_ms": round((ack-start)*1000, 3),
                                          "ack_to_timeline_ms": round((timeline-ack)*1000, 3),
                                          "timeline_present": cache().zscore("v1:feed:global_timeline", video_id) is not None,
                                          "counter_delta": {k: v-before[k] for k,v in metrics_snapshot().items()}})
        newest = result["samples"][-1]["video_id"]
        # A distinct page size guarantees a cache miss for the control observation.
        _, cold_page = await post(session, "/feed/listByFollowing", warm_reader, {"limit": 11, "latest_time": 0})
        observation_start = time.perf_counter()
        seen = False
        polls = 0
        while time.perf_counter() - observation_start < 10:
            _, page = await post(session, "/feed/listByFollowing", warm_reader, {"limit": 10, "latest_time": 0})
            polls += 1
            if any(v["id"] == newest for v in page["video_list"]):
                seen = True
                break
            await asyncio.sleep(.2)
        page_key = f"v1:feed:listByFollowing:limit=10:accountID={warm_reader}:before=0"
        result["following_visibility"] = {"new_video_id": newest,
                                          "uncached_page_sees_video": any(v["id"] == newest for v in cold_page["video_list"]),
                                          "cached_page_sees_video": seen, "polls": polls,
                                          "observation_s": round(time.perf_counter()-observation_start, 3),
                                          "cached_page_remaining_ttl_s": cache().ttl(page_key)}
    (ROOT / "publishing.json").write_text(json.dumps(result, indent=2), encoding="utf8")
    print(json.dumps(result), flush=True)


def summarize():
    runs = [json.loads(line) for line in (ROOT / "runs.jsonl").read_text().splitlines()]
    assert len(runs) == 36, "Incomplete measurement matrix"
    grouped = defaultdict(list)
    for run in runs:
        with (ROOT / (run["name"] + ".csv")).open(encoding="utf8", newline="") as stream:
            rows = list(csv.DictReader(stream))
        assert len(rows) == run["requests"], run["name"]
        assert sum(row["valid_page"] == "True" for row in rows) == run["valid_pages"], run["name"]
        grouped[(run["follow_count"], run["cache"], run["target_rps"])].append(run)
    result = {"measurement_runs": len(runs), "measurement_requests": sum(r["requests"] for r in runs),
              "errors": sum(r["errors"] for r in runs), "performance": [],
              "methodology": {"api_path": BASE + "/feed/listByFollowing", "page_size": 10,
                              "window_seconds": DURATION, "repeats_per_case": REPEATS,
                              "rates": RATES, "aggregation": "median of three independently measured run P95 values",
                              "warm": "each reader's first page prewarmed through the original HTTP API",
                              "uncached": "unique historical-page cursors not requested in pilot or warmup; InnoDB buffer pool warm",
                              "load_generation": "fixed arrival rate; HTTP time and scheduler lag both retained per request",
                              "timeout_seconds": 5, "between_runs": "wait until MySQL Threads_running <= 2 twice",
                              "fixtures": "1000 main authors, 100000 videos (100/author), 1000 readers each following 20/200/1000 authors; auxiliary accounts for correctness and publishing",
                              "limits": "8-second windows are short-run baselines; 300 RPS is a tested rate; no capacity maximum established",
                              "privacy": "private/revoke feature absent; access-revocation latency remains unmeasurable"}}
    for (follow, mode, rate), values in sorted(grouped.items()):
        assert len(values) == REPEATS
        result["performance"].append({"following": follow, "cache": mode, "offered_rps": rate,
                                      "http_p95_median_ms": round(statistics.median(r["http_p95_ms"] for r in values), 3),
                                      "http_p95_range_ms": [min(r["http_p95_ms"] for r in values), max(r["http_p95_ms"] for r in values)],
                                      "scheduled_to_complete_p95_median_ms": round(statistics.median(r["e2e_p95_ms"] for r in values), 3),
                                      "errors": sum(r["errors"] for r in values),
                                      "mysql_rows_read_per_request": sum(r["counter_delta"]["Innodb_rows_read"] for r in values)/sum(r["requests"] for r in values)})
    publishing = json.loads((ROOT / "publishing.json").read_text())
    result["publishing"] = {"samples": len(publishing["samples"]), "by_follower_count": []}
    for fans in sorted({s["followers"] for s in publishing["samples"]}):
        samples = [s for s in publishing["samples"] if s["followers"] == fans]
        result["publishing"]["by_follower_count"].append({"followers": fans,
            "http_ack_median_ms": round(statistics.median(s["http_ack_ms"] for s in samples), 3),
            "ack_to_timeline_median_ms": round(statistics.median(s["ack_to_timeline_ms"] for s in samples), 3),
            "mysql_insert_rows": sorted({s["counter_delta"]["Innodb_rows_inserted"] for s in samples}),
            "mysql_deletes": sorted({s["counter_delta"]["Com_delete"] for s in samples})})
    result["publishing"]["following_visibility"] = publishing["following_visibility"]
    result["correctness"] = json.loads((ROOT / "correctness.json").read_text())
    result["pilot_note"] = "100 RPS at 200-follow uncached pages overloaded MySQL. Preserve pilot directory as investigation evidence; excluded from settled measurement runs."
    (ROOT / "summary.json").write_text(json.dumps(result, indent=2), encoding="utf8")
    print(json.dumps(result), flush=True)


if __name__ == "__main__":
    command = sys.argv[1]
    if command == "seed":
        seed()
    elif command == "summary":
        summarize()
    else:
        asyncio.run({"load": load, "correctness": correctness, "publish": publish_checks}[command]())
