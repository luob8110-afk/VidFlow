"""Render the measured baseline and package its reproducible evidence."""
import hashlib
import json
import statistics
import zipfile
from pathlib import Path

root=Path(__file__).resolve().parent
repo=Path('D:/Golang/feedsystem_video_go')
summary=json.loads((root/'summary.json').read_text(encoding='utf-8'))
env=json.loads((root/'environment.json').read_text(encoding='utf-8'))
runs=[json.loads(line) for line in (root/'runs.jsonl').read_text().splitlines() if line.strip()]
modes={'ordinary':'普通首页读取','mixed':'20% 主动刷新混合','refresh':'全部主动刷新','paging':'连续三页'}
report='''# 2.1 正确版本性能基线

2026-11-14 完成。本轮使用已经完成刷新、复合游标和组合流程验收的工作区版本，建立后续查询、缓存与分发实验的对照。

## 数据、环境与一致性

- 主负载固定 1,000 名作者、100,000 条作品，每位作者 100 条。关注组为 20、100、200 人，对主作者覆盖率分别为 2%、10%、20%。每组存储 1,000 名读者关系，由相同的 100 名活跃读者索引承担请求。
- 固定随机种子 20261114。同一读者索引的关注集合逐层包含，所有读者共同关注作者 1。每轮使用同一组发布作者、同一请求顺序和刷新比例轨迹。另有 1,000 名仅关注对应作者的新鲜度探针读者，以及一个有 25 条同时间作品的分页检查作者和读者。
- API 限制 2 核、512 MiB；MySQL 为 2 核、1 GiB，InnoDB 缓冲池 256 MiB，max_connections=300；Redis 为 1 核、256 MiB；RabbitMQ 为 1 核、768 MiB；Nginx 为 1 核、128 MiB。数据库连接池使用当前源码设置，配置和源码摘要已归档。
- 使用独立 Compose 项目、数据库与端口，经 Nginx 和原有 JWT 中间件调用 JSON API。认证凭据由测试密钥签名并预置，认证缓存保持命中。请求窗口包含令牌校验，媒体传输与浏览器渲染另外验收。
- 镜像 ID、容器环境变量、CPU 与内存限制、挂载配置、MySQL 参数、索引结构、Redis 配置和 Go 源码摘要在每轮前后比对，全部一致。原项目继续运行，全部运行容器的资源采样均已保存。
- 每轮开始前等待数据库与 Outbox 排空，清理上一轮新增作品，确认主作品恢复到 100,000 条；重置独立 Redis，再通过 API 并发预热相同工作集。MySQL 缓冲池保持热状态。

## 负载与指标口径

主负载固定每秒 20 次请求，每轮计划 120 秒、2,400 次主请求，每组每场景重复三次，顺序固定随机打散。每轮同时以每秒一次的计划发布 120 条作品，发布成功后立即由对应作者的一名探针读者主动刷新。

首页场景包括普通读取、全部主动刷新、20% 主动刷新的混合读取。三页场景由每名活跃读者循环执行一次主动刷新和两次携带复合游标的加载更多，翻页深度为三页。三页请求还检查同一浏览周期内 ID 不重复。普通请求使用实际 30 秒缓存，窗口覆盖多次过期。

当前主页点击关注、首次进入关注均使用主动刷新，实际入口应对应主动刷新指标。普通首页和 20% 混合负载为可复现的 API 合成对照。各候选方案应在相同场景内比较。

下表 P50、P95、P99 为三轮各自分位数的中位数。HTTP 耗时从实际发出请求计算，调度等待与计划发出到完成的耗时在原始记录中另列。MySQL 读取行数使用全库 InnoDB 实际读取计数，除以主请求与新鲜度探针请求总数，包含固定发布和后台 Outbox 读取的开销。

缓存命中率为普通请求的估算值。该服务器的预处理执行没有进入 SQL 摘要表，原始摘要计数保留作统计口径说明。依据当前缓存代码，普通页缺失会在外层读取和 singleflight 内二次检查中各产生一次 Redis 缺失。每轮均确认认证表读取为零、Redis 缺失数为偶数、单请求耗时小于同一读者的五秒请求间隔，然后按缺失数的一半推算未命中次数。主动刷新列的普通请求命中率为空。

## 正式结果

| 关注数 | 场景 | P50 ms | P95 ms | P99 ms | P95 三轮范围 ms | MySQL 读取行数 / Feed 请求 | 普通请求缓存命中估算 |
|---:|---|---:|---:|---:|---|---:|---:|
'''
for row in sorted(summary['aggregates'],key=lambda r:(r['follow_count'],list(modes).index(r['mode']))):
    cache='—' if row['normal_cache_hit_estimate'] is None else f"{row['normal_cache_hit_estimate']*100:.1f}%"
    low,high=row['http_p95_range_ms']
    report+=f"| {row['follow_count']} | {modes[row['mode']]} | {row['http_p50_ms']:.2f} | {row['http_p95_ms']:.2f} | {row['http_p99_ms']:.2f} | {low:.2f}–{high:.2f} | {row['mysql_rows_per_feed']:,.1f} | {cache} |\n"
report+=f'''
共完成 {summary['runs']} 轮、{summary['main_requests']:,} 次主请求、{summary['publications']:,} 次发布和 {summary['freshness_checks']:,} 次发布后主动刷新检查，正式测量请求共 {summary['main_requests']+summary['publications']+summary['freshness_checks']:,} 次，错误数为零。发布后刷新均在返回首页中找到新作品。每轮前后的固定同时间分页检查均取得 25 条、去重 25 条，页数为 10、10、5。

## 发布与排空

每轮业务表计数均为每次发布新增一条作品、一条 Outbox 记录，投递后删除一条 Outbox 记录。发布标题不含标签。发布路径持续使用当前读时聚合方案。

'''
publish_p95=[r['kinds']['publish']['http_p95_ms'] for r in runs]
fresh_p95=[r['kinds']['freshness']['http_p95_ms'] for r in runs]
report+=f"发布 HTTP P95 的轮间范围为 {min(publish_p95):.2f}–{max(publish_p95):.2f} ms。发布响应后立即刷新探针的 HTTP P95 范围为 {min(fresh_p95):.2f}–{max(fresh_p95):.2f} ms。探针每人只关注对应的一名作者，其延迟需要与主组指标分别解释。\n\n"
report+=f"正常停发后的 Outbox 与数据库排空检查最长为 {max(r['drain_s'] for r in runs):.3f} 秒。该指标覆盖本轮稳定负载的排空，高峰积压恢复安排在后续实验中验证。\n\n"
report+='## 资源采样\n\nCPU 百分比按一个逻辑核为 100% 解释。内存取测量窗口内 Docker stats 的最大观测值。\n\n| 服务 | CPU P95 | CPU 最大观测值 | 内存最大观测值 MiB |\n|---|---:|---:|---:|\n'
def memory_mib(sample):
    import re
    value,unit=re.match(r'([\d.]+)(\w+)',sample.split('/')[0].strip()).groups()
    factors={'B':1/1048576,'kB':1000/1048576,'KiB':1/1024,'MB':1000000/1048576,'MiB':1,'GB':1000000000/1048576,'GiB':1024}
    return float(value)*factors[unit]
for service in ['backend','mysql','redis','rabbitmq','web']:
    value=summary['resources'][f'vidflow-correct-baseline-{service}-1']
    report+=f"| {service} | {value['cpu_p95_percent']:.2f}% | {value['cpu_max_percent']:.2f}% | {max(memory_mib(v) for v in value['memory_samples']):.1f} |\n"
report+='\n'
report+='''## 测量异常与边界

校准时发现 SQL 摘要未统计应用预处理执行，已调整统计口径并重新开始正式矩阵。另有一轮客户端调度发生约 18 分钟中断，实际持续约 1,219 秒，恢复后补发形成突发并出现 25 次 HTTP 500。该轮已单独保存到 pilot/interrupted，移出正式统计并重跑通过。负载器随后增加一秒调度中断检测，恢复后停止该轮，避免补发改变负载。

本轮验证固定 20 次主请求/秒和一次发布/秒下的延迟、读取成本与正确性。最大稳定容量、真实访问分布和跨机器网络影响留待后续负载实验。每组 100 名活跃读者、20% 混合刷新和三页浏览深度均为实验参数。未来关注 1 万、10 万人的情形按设计推演处理。

## 后续对照入口

本轮执行计划在三组中均显示按关注作者读取作品再排序，关注 200 人时需读取约 2 万条候选作品。2.2 优先围绕这一查询路径比较候选索引和查询写法，并保持本轮数据、资源、刷新契约和请求轨迹一致。

## 复现与证据

归档包含冻结的 Compose、配置、负载与汇总脚本、环境和源码摘要、源码快照、SQL 执行计划、逐请求 CSV、资源采样、每轮计数器及校准和中断记录。负载脚本中断前后的版本均保留。正式结果由 summarize.py 生成，36 轮都通过环境、时序和正确性检查。

从空的独立项目启动环境后，通过 backend/Dockerfile 的 api 目标构建归档对应源码，执行 baseline.py seed，再执行 baseline.py load 和 baseline.py paging。load 与 paging 支持按已完成轮次续跑。重现应使用归档内相同的镜像与运行参数。已有样本数据库保留在停止的独立容器中。

[原始证据归档](correct-baseline-20261114.zip)
'''
target=repo/'experiments/feed-following'
report=report.replace('；','，').replace('MySQL 参数、索引结构','MySQL 参数、作品表索引结构')
(target/'04-correct-version-baseline.md').write_text(report,encoding='utf-8')
for relative,expected in env['source_hashes'].items():
    assert hashlib.sha256((repo/relative).read_bytes()).hexdigest()==expected
checksums={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in root.rglob('*') if p.is_file() and '__pycache__' not in str(p) and p.name!='SHA256SUMS.json'}
(root/'SHA256SUMS.json').write_text(json.dumps(checksums,indent=2),encoding='utf-8')
archive=target/'correct-baseline-20261114.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for p in root.rglob('*'):
        if p.is_file() and '__pycache__' not in str(p):z.write(p,str(p.relative_to(root)))
    for relative in env['source_hashes']:z.write(repo/relative,'source/'+relative)
    for relative in ['backend/go.mod','backend/go.sum','backend/Dockerfile']:z.write(repo/relative,'source/'+relative)
print(json.dumps({'report':str(target/'04-correct-version-baseline.md'),'archive':str(archive),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}))
with (target/'04-correct-version-baseline.md').open('a',encoding='utf-8') as stream:
    stream.write('\n归档 SHA-256 为 `'+hashlib.sha256(archive.read_bytes()).hexdigest()+'`。\n')
