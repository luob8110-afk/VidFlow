"""Aggregate only the completed, valid, uniform baseline runs."""
import json
import math
import statistics
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent
runs = [json.loads(line) for line in (ROOT/'runs.jsonl').read_text().splitlines() if line.strip()]
assert len(runs) == 36
assert all(119 <= run['elapsed_s'] <= 125 for run in runs)
assert all(run['environment_match'] and run['cache_estimate_assumptions_hold'] for run in runs)
assert all(not kind['errors'] for run in runs for kind in run['kinds'].values())
assert all(run['kinds']['main']['requests'] == 2400 and run['kinds']['publish']['requests'] == 120 for run in runs)
groups = defaultdict(list)
for run in runs:
    groups[(run['follow_count'], run['mode'])].append(run)
aggregated = []
for (count, mode), selected in sorted(groups.items()):
    assert len(selected) == 3
    def median(path):
        values = []
        for run in selected:
            value = run
            for key in path:
                value = value[key]
            if value is not None:
                values.append(value)
        return round(statistics.median(values), 3) if values else None
    p95s = [r['kinds']['main']['http_p95_ms'] for r in selected]
    aggregated.append({'follow_count':count,'mode':mode,'requests':7200,'errors':0,
        'http_p50_ms':median(('kinds','main','http_p50_ms')),
        'http_p95_ms':median(('kinds','main','http_p95_ms')),
        'http_p99_ms':median(('kinds','main','http_p99_ms')),
        'http_p95_range_ms':[min(p95s),max(p95s)],
        'scheduler_p95_ms':median(('kinds','main','scheduler_p95_ms')),
        'scheduled_p95_ms':median(('kinds','main','scheduled_p95_ms')),
        'valid_rps_including_drain':median(('kinds','main','valid_rps_including_drain')),
        'normal_cache_hit_estimate':median(('normal_cache_hit_estimate',)),
        'mysql_rows_per_feed':median(('mysql_rows_read_per_feed_request',)),
        'publication_p95_ms':median(('kinds','publish','http_p95_ms')),
        'freshness_p95_ms':median(('kinds','freshness','http_p95_ms')),
        'settle_max_s':max(r['drain_s'] for r in selected)})
resources = defaultdict(lambda: {'cpu_percent':[],'memory':[]})
for run in runs:
    samples=json.loads((ROOT/(run['name']+'-resources.json')).read_text())
    for sample in samples:
        for container in sample['containers']:
            name=container['Name']
            resources[name]['cpu_percent'].append(float(container['CPUPerc'].rstrip('%')))
            resources[name]['memory'].append(container['MemUsage'])
resource_summary={name:{'cpu_p95_percent':sorted(value['cpu_percent'])[math.ceil(len(value['cpu_percent'])*.95)-1],
                        'cpu_max_percent':max(value['cpu_percent']), 'memory_samples':sorted(set(value['memory']))}
                  for name,value in resources.items()}
summary={'runs':len(runs),'main_requests':sum(r['kinds']['main']['requests'] for r in runs),
         'publications':sum(r['kinds']['publish']['requests'] for r in runs),
         'freshness_checks':sum(r['kinds']['freshness']['requests'] for r in runs),
         'formal_errors':0,'aggregates':aggregated,'resources':resource_summary,
         'business_writes_per_publish':{'video_insert_values':sorted(set(r['settled_counter_delta']['videos_insert']/120 for r in runs)),
                                      'outbox_insert_values':sorted(set(r['settled_counter_delta']['outbox_msgs_insert']/120 for r in runs)),
                                      'outbox_delete_values':sorted(set(r['settled_counter_delta']['outbox_msgs_delete']/120 for r in runs))}}
(ROOT/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
print(json.dumps({key:value for key,value in summary.items() if key!='resources'},indent=2))
