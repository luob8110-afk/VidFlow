"""Start the identical-resource pagination workload after the primary matrix drains."""
import json
import subprocess
import sys
import time
from pathlib import Path

root=Path(__file__).resolve().parent
while not (root/'load.done').exists():
    error=(root/'resume-errors.log').read_text()
    if error.strip():
        raise RuntimeError('Primary matrix requires inspection before pagination')
    time.sleep(10)
runs=[json.loads(line) for line in (root/'runs.jsonl').read_text().splitlines() if line.strip()]
assert len(runs)==27
with (root/'paging-progress.log').open('w') as output, (root/'paging-errors.log').open('w') as errors:
    result=subprocess.run([sys.executable,'-u',str(root/'baseline.py'),'paging'],stdout=output,stderr=errors,
                          creationflags=subprocess.CREATE_NO_WINDOW)
sys.exit(result.returncode)
