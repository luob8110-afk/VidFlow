"""Correctness-preserving baseline. Run only against the named isolated Compose project."""
import asyncio
import base64
import csv
import hashlib
import hmac
import json
import math
import random
import subprocess
import sys
import time
from collections import Counter
from datetime import datetime, timedelta
from pathlib import Path

import aiohttp
import pymysql
import redis

ROOT = Path(__file__).resolve().parent
REPO = Path('D:/Golang/feedsystem_video_go')
PROJECT = 'vidflow-correct-baseline'
BASE = 'http://127.0.0.1:18081/api'
COUNTS = (20, 100, 200)
READERS = 1000
ACTIVE = 100
AUTHORS = 1000
VIDEOS = 100000
SEED = 20261114
DURATION = 120
REPEATS = 3
RATE = 20
SECRET = b'vidflow-baseline-test-only'
DATA_TIME = datetime(2026, 11, 1, 12)


def dump(name, value):
    (ROOT / name).write_text(json.dumps(value, indent=2, default=str), encoding='utf-8')


def db():
    return pymysql.connect(host='127.0.0.1', port=13308, user='root', password='baseline-local',
                           database='vidflow_correct_baseline', autocommit=True)


def cache():
    return redis.Redis(host='127.0.0.1', port=16380, password='baseline-local')


def token(account):
    def encode(value):
        return base64.urlsafe_b64encode(json.dumps(value, separators=(',', ':')).encode()).rstrip(b'=')
    # Fixed fixture credentials cover the entire run and subsequent reproduction window.
    head = encode({'alg': 'HS256', 'typ': 'JWT'})
    body = encode({'account_id': account, 'username': f'bench{account}', 'iat': 1794528000,
                   'nbf': 1794528000, 'exp': 1893456000})
    message = head + b'.' + body
    signature = base64.urlsafe_b64encode(hmac.new(SECRET, message, hashlib.sha256).digest()).rstrip(b'=')
    return (message + b'.' + signature).decode()


def reader_id(group, index):
    return 10000 + group * READERS + index


def follows(group, index):
    authors = list(range(2, AUTHORS + 1))
    random.Random(SEED + index).shuffle(authors)
    return {1, *authors[:COUNTS[group] - 1]}


def seed():
    with db() as conn, conn.cursor() as cur:
        cur.execute('SELECT COUNT(*) FROM accounts')
        if cur.fetchone()[0]:
            raise RuntimeError('Isolated database already contains accounts')
        accounts = list(range(1, 1002)) + list(range(10000, 13000)) + list(range(30001, 31001)) + [40000]
        cur.executemany('INSERT INTO accounts (id,username,password,token,refresh_token) VALUES (%s,%s,%s,%s,%s)',
                        [(i, f'bench{i}', 'unused-fixture-password', token(i), '') for i in accounts])
        for start in range(1, VIDEOS + 1, 2000):
            rows = [(i, (i - 1) % AUTHORS + 1, f'bench{(i - 1) % AUTHORS + 1}', f'fixture{i}',
                     '/fixture.mp4', '/fixture.jpg', DATA_TIME + timedelta(seconds=i), 0, 0) for i in range(start, start + 2000)]
            cur.executemany('INSERT INTO videos (id,author_id,username,title,play_url,cover_url,create_time,likes_count,popularity) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s)', rows)
        edges = []
        for group in range(3):
            for index in range(READERS):
                edges.extend((reader_id(group, index), author) for author in sorted(follows(group, index)))
                if len(edges) >= 5000:
                    cur.executemany('INSERT INTO socials (follower_id,vlogger_id) VALUES (%s,%s)', edges)
                    edges.clear()
        edges.extend((30000 + author, author) for author in range(1, 1001))
        edges.append((40000, 1001))
        cur.executemany('INSERT INTO socials (follower_id,vlogger_id) VALUES (%s,%s)', edges)
        cur.executemany('INSERT INTO videos (id,author_id,username,title,play_url,cover_url,create_time,likes_count,popularity) VALUES (%s,1001,%s,%s,%s,%s,%s,0,0)',
                        [(200001+i, 'bench1001', f'tie{i}', '/fixture.mp4', '/fixture.jpg', datetime(2026, 11, 3)) for i in range(25)])
        cur.execute('ANALYZE TABLE accounts,videos,socials,likes')
        counts = {}
        for table in ('accounts', 'videos', 'socials'):
            cur.execute(f'SELECT COUNT(*) FROM {table}')
            counts[table] = cur.fetchone()[0]
    dump('fixture.json', {'main_authors': AUTHORS, 'main_videos': VIDEOS, 'groups': COUNTS, 'readers_per_group': READERS,
                         'active_per_group': ACTIVE, 'seed': SEED, 'counts': counts, 'duration_s': DURATION,
                         'repeats': REPEATS, 'main_rps': RATE, 'publish_rps': 1,
                         'nested_follows': 'same reader index has nested 20/100/200 author sets',
                         'auxiliary': '1000 one-author freshness readers and one 25-work correctness reader'})


def environment():
    names = [f'{PROJECT}-{service}-1' for service in ('mysql', 'redis', 'rabbitmq', 'backend', 'web')]
    inspected = json.loads(subprocess.check_output(['docker', 'inspect', *names], text=True))
    containers = []
    for item in inspected:
        containers.append({'name': item['Name'], 'image': item['Image'], 'env': sorted(item['Config']['Env']),
                           'nano_cpus': item['HostConfig']['NanoCpus'], 'memory': item['HostConfig']['Memory'],
                           'entrypoint': item['Config']['Entrypoint'], 'cmd': item['Config']['Cmd'],
                           'mounts': item['Mounts']})
    with db() as conn, conn.cursor() as cur:
        cur.execute("SHOW VARIABLES WHERE Variable_name IN ('version','innodb_buffer_pool_size','max_connections','transaction_isolation','sql_mode','time_zone','optimizer_switch')")
        mysql = dict(cur.fetchall())
        cur.execute('SHOW CREATE TABLE videos')
        table = cur.fetchone()[1]
    # AUTO_INCREMENT changes with publishing, independently of schema or index layout.
    import re
    table = re.sub(r'AUTO_INCREMENT=\d+', 'AUTO_INCREMENT=<dynamic>', table)
    sources = {str(p.relative_to(REPO)): hashlib.sha256(p.read_bytes()).hexdigest()
               for p in sorted((REPO/'backend').rglob('*.go'))}
    configs = {name: hashlib.sha256((ROOT/name).read_bytes()).hexdigest() for name in ('compose.yaml', 'config.yaml', 'nginx.conf')}
    return {'containers': containers, 'mysql': mysql, 'video_schema': table, 'source_hashes': sources, 'config_hashes': configs,
            'redis_config': {str(k): v.decode() if isinstance(v, bytes) else v for k, v in cache().config_get('maxmemory*').items()}}


def snapshot():
    with db() as conn, conn.cursor() as cur:
        cur.execute("SHOW GLOBAL STATUS WHERE Variable_name IN ('Com_select','Com_insert','Com_delete','Innodb_rows_read','Innodb_rows_inserted','Innodb_buffer_pool_reads','Innodb_buffer_pool_read_requests','Threads_running')")
        result = {k: int(v) for k, v in cur.fetchall()}
        cur.execute("SELECT COALESCE(SUM(COUNT_STAR),0) FROM performance_schema.events_statements_summary_by_digest WHERE SCHEMA_NAME=DATABASE() AND DIGEST_TEXT LIKE 'SELECT %' AND DIGEST_TEXT LIKE '%`videos`%' AND DIGEST_TEXT LIKE '%`socials`%'")
        result['feed_queries'] = int(cur.fetchone()[0])
        cur.execute("SELECT OBJECT_NAME,COUNT_FETCH,COUNT_INSERT,COUNT_DELETE FROM performance_schema.table_io_waits_summary_by_table WHERE OBJECT_SCHEMA=DATABASE()")
        for name, fetch, insert, delete in cur.fetchall():
            result.update({f'{name}_fetch': int(fetch), f'{name}_insert': int(insert), f'{name}_delete': int(delete)})
    result.update({'redis_'+k: int(cache().info('stats')[k]) for k in ('keyspace_hits', 'keyspace_misses', 'total_commands_processed')})
    return result


async def post(session, path, account, body):
    async with session.post(BASE+path, json=body, headers={'Authorization': 'Bearer '+token(account)}) as response:
        return response.status, await response.json(content_type=None)


async def settle():
    for _ in range(45):
        with db() as conn, conn.cursor() as cur:
            cur.execute("SELECT COUNT(*) FROM information_schema.PROCESSLIST WHERE DB=DATABASE() AND COMMAND<>'Sleep' AND ID<>CONNECTION_ID() AND INFO NOT LIKE '%outbox_msgs%'")
            busy = cur.fetchone()[0]
            cur.execute("SELECT COUNT(*) FROM outbox_msgs")
            pending = cur.fetchone()[0]
        if busy == 0 and pending == 0:
            return
        await asyncio.sleep(1)
    raise RuntimeError('database or outbox did not drain')


def pct(values, p):
    ordered = sorted(values)
    return round(ordered[max(0, math.ceil(len(ordered)*p)-1)], 3) if ordered else None


async def correctness(session):
    cursor = ''; received = []; sizes = []
    for page in range(4):
        status, body = await post(session, '/feed/listByFollowing', 40000,
                                  {'limit': 10, 'cursor': cursor, 'refresh': page == 0})
        assert status == 200, body
        sizes.append(len(body['video_list']))
        received.extend(v['id'] for v in body['video_list'])
        if not body['has_more']:
            break
        cursor = body['next_cursor']
    assert received == list(range(200025, 200000, -1)) and sizes == [10,10,5], (received, sizes)
    return {'received': len(received), 'unique': len(set(received)), 'page_sizes': sizes}


async def run_case(session, group, mode, repeat, expected_env):
    await settle()
    with db() as conn, conn.cursor() as cur:
        cur.execute('DELETE FROM videos WHERE id>100000 AND author_id<=1000')
        cur.execute('SELECT COUNT(*) FROM videos WHERE author_id<=1000')
        assert cur.fetchone()[0] == VIDEOS
    cache().flushdb()  # Dedicated, isolated Redis instance owned by this experiment.
    pipe = cache().pipeline()
    for i in list(range(1,1002)) + list(range(10000,13000)) + list(range(30001,31001)) + [40000]:
        pipe.set(f'v1:account:{i}', token(i), ex=7200)
    pipe.execute()
    assert environment() == expected_env, 'environment drift before run'
    authors = list(range(1,1001)); random.Random(SEED).shuffle(authors)
    # Warm identical main and freshness working sets through the real endpoint.
    warm_started = time.perf_counter()
    warm_limit = asyncio.Semaphore(10)
    async def warm_one(account):
        async with warm_limit:
            status, _ = await post(session, '/feed/listByFollowing', account, {'limit': 10})
            assert status == 200
    await asyncio.gather(*(warm_one(account) for account in [reader_id(group,i) for i in range(ACTIVE)] + [30000+a for a in authors[:DURATION]]))
    warm_elapsed = time.perf_counter()-warm_started
    await correctness(session)
    before = snapshot()
    name = f'f{COUNTS[group]}_{mode}_r{repeat}'
    started = time.perf_counter(); wall_started = time.time()
    rows = []; resource_rows = []; pending = set()
    follow_sets = {reader_id(group,i): follows(group,i) for i in range(ACTIVE)}
    refresh_flags = []
    for block in range(math.ceil(RATE*DURATION/100)):
        flags = [True]*20+[False]*80
        random.Random(SEED+block).shuffle(flags)
        refresh_flags.extend(flags)

    async def one(kind, sequence, account, body, target, expected_id=None):
        sent = time.perf_counter(); status = 0; valid = False; error = ''
        try:
            status, data = await post(session, '/feed/listByFollowing', account, body)
            page = data.get('video_list', [])
            valid = status == 200 and len(page) == 10 and len({v['id'] for v in page}) == 10
            if kind == 'main':
                valid = valid and all(v['author']['id'] in follow_sets[account] for v in page)
                valid = valid and all((a['create_time'],a['id']) >= (b['create_time'],b['id']) for a,b in zip(page,page[1:]))
                valid = valid and data.get('has_more') and bool(data.get('next_cursor'))
            if expected_id is not None:
                valid = valid and bool(page) and page[0]['id'] == expected_id
            if not valid: error = str(data)[:200]
        except Exception as exc:
            error = f'{type(exc).__name__}: {exc}'
        end = time.perf_counter()
        rows.append({'kind':kind,'sequence':sequence,'account':account,'refresh':body.get('refresh',False),
                     'status':status,'valid':bool(valid),'scheduler_ms':(sent-target)*1000,'http_ms':(end-sent)*1000,
                     'scheduled_to_complete_ms':(end-target)*1000,'finished_s':end-started,'error':error})

    async def publications():
        for seq in range(DURATION):
            target = started + seq
            await asyncio.sleep(max(0,target-time.perf_counter()))
            author = authors[seq]; sent = time.perf_counter()
            try:
                status, data = await post(session,'/video/publish',author,
                                          {'title':f'baseline-{seq}','play_url':'/fixture.mp4','cover_url':'/fixture.jpg'})
                end = time.perf_counter(); valid = status==200 and bool(data.get('id'))
                rows.append({'kind':'publish','sequence':seq,'account':author,'refresh':False,'status':status,'valid':valid,
                             'scheduler_ms':(sent-target)*1000,'http_ms':(end-sent)*1000,'scheduled_to_complete_ms':(end-target)*1000,
                             'finished_s':end-started,'error':'' if valid else str(data)[:200]})
                if valid:
                    await one('freshness',seq,30000+author,{'limit':10,'refresh':True},end,data['id'])
            except Exception as exc:
                rows.append({'kind':'publish','sequence':seq,'account':author,'refresh':False,'status':0,'valid':False,
                             'scheduler_ms':0,'http_ms':(time.perf_counter()-sent)*1000,'scheduled_to_complete_ms':0,
                             'finished_s':time.perf_counter()-started,'error':str(exc)})

    async def resources():
        for sec in range(0,DURATION,10):
            await asyncio.sleep(max(0,started+sec-time.perf_counter()))
            output = await asyncio.to_thread(subprocess.check_output,
                ['docker','stats','--no-stream','--format','{{json .}}'], text=True)
            resource_rows.append({'elapsed_s':time.perf_counter()-started,'containers':[json.loads(line) for line in output.splitlines()]})
            if sec == 60:
                main = [r for r in rows if r['kind']=='main']
                print(json.dumps({'progress':name,'elapsed_s':60,'main_completed':len(main),'errors':sum(not r['valid'] for r in main)}),flush=True)

    publishing = asyncio.create_task(publications()); sampling = asyncio.create_task(resources())
    for seq in range(RATE*DURATION):
        target = started + seq/RATE
        await asyncio.sleep(max(0,target-time.perf_counter()))
        refresh = mode=='refresh' or (mode=='mixed' and refresh_flags[seq])
        task = asyncio.create_task(one('main',seq,reader_id(group,seq%ACTIVE),{'limit':10,'refresh':refresh},target))
        pending.add(task); task.add_done_callback(pending.discard)
    await asyncio.gather(*pending, publishing, sampling)
    elapsed = time.perf_counter()-started
    after = snapshot()
    drain_started = time.perf_counter()
    await settle()
    drain_elapsed = time.perf_counter()-drain_started
    after_drain = snapshot()
    post_correctness = await correctness(session)
    assert environment() == expected_env, 'environment drift after run'
    with (ROOT/(name+'.csv')).open('w',newline='',encoding='utf-8') as stream:
        writer=csv.DictWriter(stream,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    dump(name+'-resources.json',resource_rows)
    delta = {key: after[key]-before[key] for key in before}
    summary = {'name':name,'follow_count':COUNTS[group],'mode':mode,'repeat':repeat,'started_unix':wall_started,
               'elapsed_s':round(elapsed,3),'warmup_s':round(warm_elapsed,3),'drain_s':round(drain_elapsed,3),
               'environment_match':True,'pagination':post_correctness,'counter_delta':delta,
               'settled_counter_delta':{k:after_drain[k]-before[k] for k in before},'kinds':{}}
    for kind in ('main','publish','freshness'):
        selected=[r for r in rows if r['kind']==kind]; success=[r for r in selected if r['valid']]
        summary['kinds'][kind]={'requests':len(selected),'errors':len(selected)-len(success),
            'status':dict(Counter(r['status'] for r in selected)),'http_p50_ms':pct([r['http_ms'] for r in success],.5),
            'http_p95_ms':pct([r['http_ms'] for r in success],.95),'http_p99_ms':pct([r['http_ms'] for r in success],.99),
            'scheduler_p95_ms':pct([r['scheduler_ms'] for r in selected],.95),
            'scheduled_p95_ms':pct([r['scheduled_to_complete_ms'] for r in selected],.95),
            'valid_rps_including_drain':round(len(success)/elapsed,3)}
    main=[r for r in rows if r['kind']=='main']; probes=summary['kinds']['freshness']['requests']
    refreshed=sum(r['refresh'] for r in main); normal=len(main)-refreshed
    # Prepared statement executions are absent from this server's SQL digest table.
    # With preloaded auth/version keys, every ordinary page miss executes two GETs
    # for the missing page (outer read and singleflight double-check).
    normal_queries=delta['redis_keyspace_misses']/2
    summary.update({'main_refreshes':refreshed,'normal_requests':normal,'normal_query_count':normal_queries,
                    'normal_cache_hit_estimate':round(1-normal_queries/normal,6) if normal else None,
                    'cache_estimate_assumptions_hold':delta['redis_keyspace_misses']%2==0 and delta['accounts_fetch']==0 and max(r['http_ms'] for r in main)<ACTIVE/RATE*1000,
                    'feed_query_count_estimate':normal_queries+refreshed+probes,
                    'mysql_rows_read_per_feed_request':round(delta['Innodb_rows_read']/(len(main)+probes),3)})
    with (ROOT/'runs.jsonl').open('a',encoding='utf-8') as stream: stream.write(json.dumps(summary)+'\n')
    print(json.dumps(summary),flush=True)
    if any(r['kinds'][kind]['errors'] for r in [summary] for kind in ('main','publish','freshness')):
        raise RuntimeError('invalid request result; inspect this run before continuing')


async def load():
    expected = environment(); dump('environment.json',expected)
    host=json.loads(subprocess.check_output(['docker','info','--format','{{json .}}'],text=True))
    dump('host.json',{k:host.get(k) for k in ('ServerVersion','OperatingSystem','NCPU','MemTotal','KernelVersion')})
    plans={}
    with db() as conn,conn.cursor() as cur:
        for group,count in enumerate(COUNTS):
            cur.execute('EXPLAIN ANALYZE SELECT * FROM videos WHERE author_id IN (SELECT vlogger_id FROM socials WHERE follower_id=%s) ORDER BY create_time DESC,id DESC LIMIT 11',(reader_id(group,0),))
            plans[str(count)]=cur.fetchone()[0]
    dump('plans.json',plans)
    cases=[(g,m,r) for g in range(3) for m in ('ordinary','refresh','mixed') for r in range(1,REPEATS+1)]
    random.Random(SEED).shuffle(cases);dump('order.json',cases)
    async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=5),connector=aiohttp.TCPConnector(limit=200)) as session:
        for group,mode,repeat in cases:
            await run_case(session,group,mode,repeat,expected)
    (ROOT/'load.done').touch()


if __name__=='__main__':
    if sys.argv[1]=='seed':seed()
    elif sys.argv[1]=='load':asyncio.run(load())
